<?php
namespace ivole\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
