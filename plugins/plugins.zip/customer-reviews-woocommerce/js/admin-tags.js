jQuery(document).ready(function() {
  jQuery(".cr_tags").select2({
    tags: true,
    tokenSeparators: [',', ' '],
    width: '100%'
  });
});
