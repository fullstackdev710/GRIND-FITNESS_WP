<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
				</div>
			</div>
			<div class="cr-form-footer">
				<?php echo $cr_form_footer; ?>
			</div>
		</div>
	</body>
</html>
